#' @useDynLib jsonify, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL
