library(testthat)
library(leafpm)

test_check("leafpm")
